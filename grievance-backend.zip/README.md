# Grievance Backend

This is a simple Express.js backend that allows your girlfriend to submit grievances, which are then emailed directly to you 💌.

## How it works
- Uses Express + Nodemailer.
- Takes grievance info via POST.
- Sends an email to the configured Gmail address.

Made with ❤️ for Veduuuu!
